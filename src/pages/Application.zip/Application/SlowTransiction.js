//慢事务追踪
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import 'pages/Application/slowTransiction.css';
import Slow_sql from 'pages/Application/slow_sql.js';
import Slow_abstract from 'pages/Application/slow_abstract.js';
import Slow_details from 'pages/Application/slow_details';
import { Icon } from 'antd';
// import Header from 'pages/functionalCom/Header.js';
// import SortHeader from 'pages/functionalCom/SortHeader.js';
import myAjax from 'pages/functionalCom/myAjax.js';
const ajax=myAjax.myAjax;
class SlowTransiction extends Component{  
	componentWillMount() {
        this.props.willMount(this.props.headerOptionsID,this.props.spanId);
        // console.log(this.props.headerOptionsID,'hx90');
        console.log(this.props.spanId,'hx100')
    }
    componentDidMount() {
        this.props.init();
    } 
    render() {
    	let {mswz,hxTable,show1,show2,show3,slowPage='abstract',goback}=this.props;
        return (
            <div className='slowTransiction'>
                <div className='slow_title'>慢事务追踪<span onClick={()=>goback()}>返回<Icon type="rollback" /></span></div>
                <table className='slow_message'>
                    <thead>
                    <tr><td>应用</td></tr>
                    <tr><td>事务</td></tr>
                    <tr><td>追踪时间</td></tr>
                    <tr><td>服务器响应时间</td> </tr>
                    </thead>
                    <tbody>
                            {
                                hxTable && hxTable.map((value,i)=>{
                                    console.log(i,'i')
                                    return(
                                         <div key={i} >
                                            <span>{value.applicationName}</span>
                                            <span>{value.rpc}</span>
                                            <span>{value.traceTime}</span>
                                            <span>{value.responseTime}</span>
                                        </div>
                                    )
                                })
                            }
                        </tbody>
                </table>
                <div className='slow_content'>
                    <div className='slow_content_tab'>
                        <span className={slowPage=='abstract' ? 'active':'normal'} id='abstract' onClick={()=>show1('abstract')}>摘要</span>
                        <span className={slowPage=='details' ? 'active':'normal'} id='details' onClick={()=>show2('details')}>追踪详情</span>
                        <span className={slowPage=='sql' ? 'active':'normal'} id='sql' onClick={()=>show3('sql')}>相关SQL</span>
                    </div>
                    <div className='slow_content_request'>
                        <div className='slow_content_request_title'> 请求信息</div>
                        <table className='slow_content_request_text'>
                            <tbody>
                                <tr><td>请求URl:</td><td>PHP Application</td></tr>
                                <tr><td>线程名称:</td><td>首页</td></tr>
                                <tr><td>HTTP响应:</td><td>2018</td></tr>
                                <tr><td>referer:</td><td>2.2（s）</td></tr>
                                <tr><td>user-agent:</td><td>PHP:ucd-ty-app-demo-1.ucd.tingyun.com</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div className='slow_content_request2'>
                        <div className='slow_content_request2_title'> 请求参数</div>
                        <table className='slow_content_request2_text'>
                            <tbody>
                                <tr><td>请求URl:</td><td>PHP Application</td></tr>
                                <tr><td>线程名称:</td><td>首页</td></tr>
                                <tr><td>HTTP响应:</td><td>2018</td></tr>
                                <tr><td>referer:</td><td>2.2（s）</td></tr>
                                <tr><td>user-agent:</td><td>PHP:ucd-ty-app-demo-1.ucd.tingyun.com</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div className='slow_content_text'>
                        {slowPage=='sql' && <Slow_sql/>}
                        {slowPage=='abstract' && <Slow_abstract/>}
                        {slowPage=='details' && <Slow_details/>}
                    </div>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        slowPage:state.vars.slowPage,
        headerOptionsID : state.vars.headerOptionsID,//默认ID
        hxTable:state.vars.hxTable,
        spanId : state.vars.spanId,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:(headerOptionsID,spanId)=>{
            console.log(spanId,'10JQ')
            let obj2={//事务追踪
                type: 'get',
                url: 'apm/traceTitleInfo.pinpoint',
                data: 'spanId='+spanId,
                dataType: 'json'
            };
            console.log(obj2,'事务追踪1')
            ajax(obj2,callback);
            function callback(data){
                console.log('事务追踪列表',data);
                dispatch(actions.setVars('hxTable',data.objectList))
            }
    	},
    	init:()=>{
    		
    	},
        show1:(page)=>{
            dispatch(actions.setVars('slowPage',page))
        },
        show2:(page)=>{
            dispatch(actions.setVars('slowPage',page))
        },
        show3:(page)=>{
            dispatch(actions.setVars('slowPage',page)) 
        },
        goback:()=>{
            dispatch(actions.setVars('slowTransition',false))
        }        
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(SlowTransiction);