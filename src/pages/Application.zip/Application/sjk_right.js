//数据库
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import 'pages/Application/sjk_right.css';
import { Icon } from 'antd';
import myAjax from 'pages/functionalCom/myAjax.js';
import SwChart5 from 'pages/chart/SwChart5.js';
const ajax=myAjax.myAjax;

class Sjk_right extends Component{  
	componentWillMount() {
        this.props.willMount(this.props.headerOptionsID,this.props.sjk_sqlId);
        console.log(this.props.sjk_sqlId,'this.props.sjk_sqlId')
    }
    componentDidMount() {
        this.props.init();
    }
    
    render() {
        let {sjk_back,showAdd,sjk_rightData,Shujukul}=this.props;
        return (
            <div className='sjk_right'>
                <div className="back" onClick={()=>sjk_back()}><Icon type="rollback" />返回</div>
                <div className='header'>
                    <Icon type="question-circle" />
                    <span> 数据库响应时间和吞吐率</span>   
                </div>
                <SwChart5 Shujukul={Shujukul} />          
                    <div className='header'>
                            <Icon type="question-circle" />
                            <span>SQL调用预览</span>
                        </div>
                <table style={{width:'100%'}}>
                    <thead>
                        <tr>
                            <th >SQL</th>
                            <th >调用方法</th>
                            <th >总时间</th>
                            <th >最大时间</th>
                            <th >最小时间</th>
                            <th >调用次数</th>
                            <th >平均消耗时间</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        sjk_rightData && sjk_rightData.map((value,i)=>{
                            return(
                                <tr>
                                <td >{value.dataBaseSqlViewVO.sqlInfo}</td>
                                <td>{value.dataBaseSqlViewVO.apiInfo}</td>
                                <td >{value.dataBaseSqlViewVO.totalTime}</td>
                                <td >{value.maxTime}</td>
                                <td >{value.minTime}</td>
                                <td >{value.invokeTime}</td>
                                <td >{value.avgTime}</td>
                            </tr>
                            )
                        })
                       
                    }                        
                    </tbody>
                </table>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        sjk_sqlId : state.vars.sjk_sqlId,
        headerOptionsID : state.vars.headerOptionsID,//默认ID
        sjk_rightData : state.vars.sjk_rightData,
        Shujukul:state.vars.Shujukul,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:(headerOptionsID,sjk_sqlId)=>{
    		let obj1={//数据库表个
                type: 'get',
                url: 'apm/traceExpensiveSql.pinpoint' ,
                data: 'appId='+headerOptionsID+sjk_sqlId,
                dataType: 'json'
            };
            ajax(obj1,callback1);
            function callback1(data){
                console.log('数据库表个',data)
                dispatch(actions.setVars('sjk_rightData',data.objectList))
            };
            let obj2={//数据库Chars
                type: 'get',
                url: 'apm/theSqlInfo.pinpoint' ,
                data: 'appId='+headerOptionsID+'&selectType='+'SQL_BY_APP'+'&threshold=0'+'&rpc='+sjk_sqlId+'&sqlMetaDataId='+'&apiMetaId=',
                dataType: 'json'
            };
            ajax(obj2,callback2);
            function callback2(data){
                console.log('数据库Chars1',data)
              let Shujukul={
                yaxisList:[],
                maxTime:[],
                minTime:[],
                avgTime:[],
              };
            // console.log(Shujukul,'数据库Chars2')
            Shujukul.xaxisList=data.obj.xaxisList;
            for(let i=0;i<data.obj.yaxisList.length;i++){
                Shujukul.maxTime.push(data.obj.yaxisList[i].maxTime);
                Shujukul.avgTime.push(data.obj.yaxisList[i].avgTime);
                Shujukul.minTime.push(data.obj.yaxisList[i].minTime);
                dispatch(actions.setVars('Shujukul',Shujukul))
            }
            }
    	},
    	init:()=>{
    		
    	},
        sjk_back:()=>{
            dispatch(actions.setVars('sjk_right',false))
        },
        showAdd:()=>{
            dispatch(actions.setVars('addInstrument',true));
        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Sjk_right);