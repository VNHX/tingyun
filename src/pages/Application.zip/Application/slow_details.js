//慢事务，追踪详情
import React, {
    Component
} from 'react';
import {
    connect
} from 'react-redux';
import actions from 'actions';
import './slow_details.css';
import myAjax from 'pages/functionalCom/myAjax.js';
const ajax = myAjax.myAjax;

class Slow_sql extends Component {
    componentWillMount() {
        this.props.willMount(this.props.headerOptionsID, this.props.spanId);
        console.log(this.props.spanId, '追踪详情')
    }
    componentDidMount() {
        this.props.init();
    }
    render() {
        let {
            slow_detailsData
        } = this.props;
        return (
            <div className='slow_details'>
            	
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        headerOptionsID: state.vars.headerOptionsID, //默认ID
        spanId: state.vars.spanId
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        willMount: (headerOptionsID, spanId) => {
            let obj1 = { //追踪详情
                type: 'get',
                url: 'apm/tracedetail.pinpoint',
                data: 'spanId=' + spanId,
                dataType: 'json'
            };
            ajax(obj1, callback1);
            console.log('追踪详情01', obj1)

            function callback1(data) {
                console.log('追踪详情02', data)
                    //dispatch(actions.setVars('slow_detailsData',data.objectList))
            }
        },
        init: () => {

        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Slow_sql);