//报表
import React, {
    Component
} from 'react';
import {
    connect
} from 'react-redux';
import actions from 'actions';
import 'pages/Application/demo.css';
import Header from 'pages/functionalCom/Header.js';
import myAjax from 'pages/functionalCom/myAjax.js';
import piedemo from 'pages/chart/demopie.js';
const ajax = myAjax.myAjax
class Bb extends Component {
    componentWillMount() {
        this.props.willMount();
    }
    componentDidMount() {
        this.props.init();
    }

    render() {
        let {
            bb_tab_flag = 'swbb', bb_body1, bb_body2, bb_body3, bb_body4, jmap, jstat, jstack, start, jid, deletejstack, detailjstack, ko
        } = this.props;
        let flag = jstat ? jstat.ec ? true : false : false;
        console.log('shuju', jstat)
        return (
            <div className='bb' id='bb'>
                <Header headerFlag={false} optionData={'more'} />
                <div className='bb_tab'>
                	<span className={bb_tab_flag=='swbb'? 'active':''} onClick={()=>bb_body1()}>标签1</span>
                	<span className={bb_tab_flag=='gjswbb'? 'active':''} onClick={()=>bb_body2()}>标签2</span>
                	<span className={bb_tab_flag=='sjkbb'? 'active':''} onClick={()=>bb_body3()}>标签3</span>
                	{/**<span className={bb_tab_flag=='nosql'? 'active':''} onClick={()=>bb_body4()}>NoSQL报表</span>**/}
                </div>
                <div className='bb_body'>
                <div className='bb_body1_header'>demo表格</div>
				{/**<div className='bb_body1_header'>
                                            <span>实例名称:</span>
                                            <select>
                                                <option>所有实例</option>
                                                <option>ucd-ty-app-demo-1:18080</option>
                                                <option>dell-goruntime:8080</option>
                                                <option>10.10.46.144:8080</option>
                                            </select>
                                            <span>时间: </span>
                                            <span><input type='checkbox' />今天</span>
                                            <span><input type='checkbox' />昨天</span>
                                            <span><input type='checkbox' />一周</span>
                                        </div> **/}
                {
                    bb_tab_flag && bb_tab_flag=='swbb' && 
						<div className='bb_body1'>
                    	<div style={{height:'50px'}}></div>
						{/**<div  className='clk'>
							<span style={{width:'25%'}}>序号</span>
							<span style={{width:'25%'}}>实例数</span>
							<span style={{width:'25%'}}>大小</span>
							<span style={{width:'25%'}}>类</span>
						</div>**/}
                    	{/**<table style={{width:'100%'}}>
                    		 <thead>
                    			<tr>
                    				<th style={{width:'25%'}}>序号</th>
                    				<th style={{width:'25%'}}>实例数</th>
                    				<th style={{width:'25%'}}>大小</th>
                    				<th style={{width:'25%'}}>类</th>
                    			</tr>
                    		</thead> 
                    		<tbody>
                    			
								<tr>
									{
										value.list.map((value,i)=>{
											console.log(i,'s')
											return(
												<tr key={i}>
													<td style={{width:'25%'}} >{value.timeType}</td>
													<td style={{width:'25%'}}>{value.avgResponseTime}</td>
													<td style={{width:'25%'}}>{value.maxResponseTime}</td>
													<td style={{width:'25%'}}>{value.minResponseTime}</td>
												</tr>
											)
										})
									}
                    			</tr>
                    		</tbody>
                    	</table>**/}

                        <table style={{width:'100%'}}> 
                            <tbody>
                                <tr>
                                    <td>序号</td>
                                    <td>实例数</td>
                                    <td>大小</td>
                                    <td>类</td>
                                </tr>
                                {
                                        jmap&&jmap.map((value,i)=>{
                                            console.log(i,'s')
                                            return(
                                <tr key={i}>
                                    <td>{value.line}</td>
                                    <td>{value.instances}</td>
                                    <td>{value.size}</td>
                                    <td>{value.className}</td>
                                </tr>
                               )
                                        })
                                    }
                    
                
                            </tbody>
                        </table>
                        <piedemo />
                    </div>
                    
				}		
                
                {
                	bb_tab_flag && bb_tab_flag=='gjswbb' && 
                	<div className='bb_body2'>
                		{/* <div className='bb_body1_header'>
                    		<span>时间: </span>
                    		<span><input type='checkbox' />今天</span>
                    		<span><input type='checkbox' />昨天</span>
                    		<span><input type='checkbox' />7日内</span>
                    		<span><input type='checkbox' />7日前</span>
                    		<span></span>
                    	</div> */}
                    	<div style={{height:'50px'}}></div>
                    	<table style={{width:'100%'}}>
                    		{/**<thead>
                    			<tr>
                    				<th>ec</th>
                    				<th>eu</th>
                    				<th>fgc</th>
                    				<th>fgct</th>
                    				<th>gct</th>
                    				<th>oc</th>
                    				<th>ou</th>
                    				<th>s0u</th>
                                    <th>s1u</th>
                                    <th>soc</th>
                                    <th>ygc</th>
                                    <th>ygct</th>
                    			</tr>
                    		</thead>**/}
                    		<tbody>
                    			<tr>
                                    <td style={{width:'8%'}}>ec</td>
                                    <td style={{width:'8%'}}>eu</td>
                                    <td style={{width:'8%'}}>fgc</td>
                                    <td style={{width:'8%'}}>fgct</td>
                                    <td style={{width:'8%'}}>gct</td>
                                    <td style={{width:'8%'}}>oc</td>
                                    <td style={{width:'8%'}}>ou</td>
                                    <td style={{width:'8%'}}>s0u</td>
                                    <td style={{width:'8%'}}>s1u</td>
                                    <td style={{width:'8%'}}>soc</td>
                                    <td style={{width:'8%'}}>ygc</td>
                                    <td style={{width:'8%'}}>ygct</td>
                                </tr>

                                {jstat&&
                                <tr>
                                    <td style={{width:'8%'}}>{flag&&jstat.ec}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.eu}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.fgc}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.fgct}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.gct}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.oc}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.ou}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.s0u}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.s1u}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.soc}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.ygc}</td>
                                    <td style={{width:'8%'}}>{flag&&jstat.ygct}</td>
                                </tr>
                                }
                    		</tbody>
                    	</table>
                	</div>
                }
                {
                	bb_tab_flag && bb_tab_flag=='sjkbb' &&
                	<div className='bb_body3'>
                		{/* <div className='bb_body1_header'>
                    		<span>实例名称:</span>
                    		<select>
                    			<option>所有实例</option>
                    			<option>ucd-ty-app-demo-1:18080</option>
                    			<option>dell-goruntime:8080</option>
                    			<option>10.10.46.144:8080</option>
                    		</select>
                    		<span>时间: </span>
                    		<span><input type='checkbox' />今天</span>
                    		<span><input type='checkbox' />昨天</span>
                    		<span><input type='checkbox' />7日内</span>
                    		<span><input type='checkbox' />7日前</span>
                    		<span></span>
                    	</div> */}
                    	<div style={{height:'50px'}}></div>
                        <div onClick={()=>start()}>生成jstack</div>
                    	<table style={{width:'100%'}}>
                    		
                    		<tbody>
                                <tr>
                                    <td><input  type="checkbox" className="selectAll"/></td>
                                    <td>时间戳</td>
                                    <td>编辑</td>
                                    <td>操作</td>
                                </tr>
                            {
                                        jstack&&jstack.map((value,i)=>{
                                            console.log(i,'s')
                                            return(
                    			<tr>
                                    <td><input type="checkbox" className='check'/></td>
                    				<td>{value}</td>
                    				<td onClick={()=>deletejstack(value)}>删除</td>
                    				<td onClick={()=>detailjstack(value)}>下载</td>
                    				
                    			</tr>
                                )
                                        })
                                    }
                    			
                    		</tbody>
                    	</table>
                	</div>
                }
                {
                	bb_tab_flag && bb_tab_flag=='nosql' &&
                	<div className='bb_body4'>
                		{/* <div className='bb_body1_header'>
                    		<span>实例名称:</span>
                    		<select>
                    			<option>所有实例</option>
                    			<option>ucd-ty-app-demo-1:18080</option>
                    			<option>dell-goruntime:8080</option>
                    			<option>10.10.46.144:8080</option>
                    		</select>
                    		<span>时间: </span>
                    		<span><input type='checkbox' />今天</span>
                    		<span><input type='checkbox' />昨天</span>
                    		<span><input type='checkbox' />7日内</span>
                    		<span><input type='checkbox' />7日前</span>
                    		<span></span>
                    	</div> */}
                    	<div style={{height:'50px'}}></div>
                    	<table style={{width:'100%'}}>
                    		<thead>
                    			<tr>
                    				<th>Memcached</th>
                    				<th>时间</th>
                    				<th>平均响应时间</th>
                    				<th>最长响应时间</th>
                    				<th>吞吐率</th>
                    			</tr>
                    		</thead>
                    		<tbody>
                    			<tr>
                    				<td rowSpan="4">JSP/index.jsp</td>
                    				<td>今日</td>
                    				<td></td>
                    				<td></td>
                    				<td></td>
                    			</tr>
                    			<tr>
                    				<td>昨日</td>
                    				<td></td>
                    				<td></td>
                    				<td></td>
                    			</tr>
                    			<tr>
                    				<td>7日内</td>
                    				<td></td>
                    				<td></td>
                    				<td></td>
                    			</tr>
                    			<tr>
                    				<td>7日前</td>
                    				<td></td>
                    				<td></td>
                    				<td></td>
                    			</tr>
                    		</tbody>
                    	</table>
                	</div>
                }                 
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        bb_tab_flag: state.vars.bb_tab_flag,
        jmap: state.vars.jmap,
        jstat: state.vars.jstat,
        jstack: state.vars.jstack,
        jid: state.vars.jid,
        ko: state.vars.ko,

    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        willMount: () => {
            let obj = { //获取jmap
                type: 'get',
                url: 'apm/jmap/jmap.pinpoint',
                data: '',
                dataType: 'json'
            };
            ajax(obj, cakklo);

            function cakklo(data) {
                console.log(data, '获取jmap')
                dispatch(actions.setVars('jmap', data.objectList))
                    // dispatch(actions.setVars('shuju',data.objectList[0].list))
                    // console.log(data.objectList[0].list,'事务报表')
                    // console.log(data.objectList[1].list,'事务报表1')
            }

            let obj1 = { //获取jstat
                type: 'get',
                url: 'apm/jstat/jstat.pinpoint',
                data: '',
                dataType: 'json'
            };
            ajax(obj1, cakklo1);

            function cakklo1(data) {
                console.log(data, '获取jstat')
                dispatch(actions.setVars('jstat', data.obj))
                    // dispatch(actions.setVars('shuju',data.objectList[0].list))
                    // console.log(data.objectList[0].list,'事务报表')
                    // console.log(data.objectList[1].list,'事务报表1')
            }

            let obj2 = { //查看jstack 列表
                type: 'get',
                url: 'apm/jstack/list.pinpoint',
                data: '',
                dataType: 'json'
            };
            ajax(obj2, cakklo2);

            function cakklo2(data) {
                console.log(data, '查看jstack 列表')
                dispatch(actions.setVars('jstack', data.objectList))
                    // dispatch(actions.setVars('shuju',data.objectList[0].list))
                    // console.log(data.objectList[0].list,'事务报表')
                    // console.log(data.objectList[1].list,'事务报表1')
                var jid = []
                for (var i = 0; i < data.objectList.length; i++) {
                    jid.push(data.objectList[i]);
                    // jid=new Array(data.objectList[i].jid);;
                    console.log(jid);
                }
                dispatch(actions.setVars('jid', jid))
                console.log(jid, '全部ID');
            }
        },
        init: () => {
            let height = $('#bb').css('height');
            $('#secondTree').css('height', height);
            $(".selectAll").on("click", function() {
                if (this.checked) {
                    $(".check").prop("checked", true);
                } else {
                    $(".check").prop("checked", false);
                }
            })
        },
        start: () => {
            let obj3 = { //生成jstack
                type: 'get',
                url: 'apm/jstack/jstack.pinpoint',
                data: '',
                dataType: 'json'
            };
            ajax(obj3, callback3);

            function callback3(data) {
                console.log('生成jstack', data);
            };
        },
        deletejstack: (value) => { //删除
            var id = new Array(value);
            let obj4 = { //删除jstack
                type: 'get',
                url: 'apm/jstack/delete.pinpoint?ids=' + id,
                data: '',
                dataType: 'json',
            }
            ajax(obj4, callback4);

            function callback4(data) {
                console.log('删除jstack', data);
                dispatch(actions.setVars('ko', data.objectList))
            };
        },
        // detailjstack: (value) => { //下载
        //     var id = new Array(value);
        //     console.log('id', id)
        //     let obj6 = { //查看jstack
        //         type: 'get',
        //         url: 'apm/jstack/view.pinpoint?fileName=' + id,
        //         data: '',
        //         dataType: 'json',
        //     }
        //     ajax(obj6, callback6);

        //     function callback6(data) {
        //         console.log('查看jstack', data);
        //         dispatch(actions.setVars('ko', data.objectList))
        //     };
        // },
        detailjstack: (value) => {
            var id = new Array(value);
            let obj6 = { //查看jstack
                type: 'get',
                url: 'apm/jstack/view.pinpoint?fileName=' + id,
                data: '',
                dataType: 'json',
            }

            var url1 = 'http://192.168.1.153:8082/' + obj6.url
            console.log('111111111111111111111111', url1)
            window.open(url1);
        },
        bb_body1: () => {
            dispatch(actions.setVars('bb_tab_flag', 'swbb'))
        },
        bb_body2: () => {
            dispatch(actions.setVars('bb_tab_flag', 'gjswbb'))
        },
        bb_body3: () => {
            dispatch(actions.setVars('bb_tab_flag', 'sjkbb'))
        },
        bb_body4: () => {
            dispatch(actions.setVars('bb_tab_flag', 'nosql'))
        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Bb);