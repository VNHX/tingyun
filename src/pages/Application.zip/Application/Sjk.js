//数据库
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import 'pages/Application/sjk.css';
import Header from 'pages/functionalCom/Header.js';
import SortHeader from 'pages/functionalCom/SortHeader.js';
import Sjk_right from './sjk_right.js';
import { Icon } from 'antd';
import SwChart3 from 'pages/chart/SwChart3.js';
import SwChart2 from 'pages/chart/SwChart2.js';
import myAjax from 'pages/functionalCom/myAjax.js';
const ajax=myAjax.myAjax;

class Sjk extends Component{  
	componentWillMount() {
        this.props.willMount(this.props.headerOptionsID);
        // console.log('sjk',this.props.headerOptionsID)
    }
    componentDidMount() {
        this.props.init();
    }
    
    render() {
    	let {showAdd,sjk_right=false,showRight,sjkList,sjk_slowSql,sjk_top,sjk_qutu,shuju,sjk_slowSql1,sjk_slowSql2}=this.props;
        let tabData=['SQL耗时','平均响应时间','吞吐率','事务响应时间','top'];
        return (
            <div className='sjk' id='sjk'>
                <Header headerFlag={true} optionData={'more'} />
                <div className='sjk_body'>
                    <SortHeader tabData={tabData}  />
                    <div className='sjk_content'>
                        <div className='sjk_content_left'>
                            <div className='sjk_content_left_titlt'>数据库一览</div>
                            <div className='sjk_content_left_input'><input/><span>搜索</span></div>
                            <ul style={{width:'100%',listStyle:'none',padding:'0'}}>
                                {
                                    sjkList && sjkList.map((value,i)=>{
                                        return(
                                            <li key={i} style={{marginBottom:'3px'}} onClick={()=>showRight(value.rpc)}>
                                                <span style={{width:'165px',height:'22px',float:'left'}}>{value.rpc}</span>
                                                <span style={{width:'50px',height:'22px',float:'right',textAlign:'center'}}>{value.totalTime}</span>
                                            </li>
                                        )
                                    })
                                }                                
                            </ul>
                        </div>
                        <div className='sjk_content_right'>
                            {
                                sjk_right && <Sjk_right />
                            }
                            <div className='header'>
                                <Icon type="question-circle" />
                                <span> TOP5 最耗时事务(墙钟时间比)堆叠图</span>
                                <span className='add' onClick={()=>showAdd()}><Icon type="plus-circle-o" /></span>
                            </div>
                            <SwChart3 sjk_top={sjk_top} />
                            <div className='header'>
                                <Icon type="question-circle" />
                                <span> 数据库响应时间曲线图</span>
                                <span className='add' onClick={()=>showAdd()}><Icon type="plus-circle-o" /></span>
                            </div>
                            <SwChart2 sjk_qutu={sjk_qutu}/>
                            <div className="sjk_content_right_table">
                                <div>
                                    <div className='header'>
		                                <Icon type="question-circle" />
		                                <span> 慢SQL追踪列表</span>
		                            </div>
                                    <div className='search' style={{marginTop: '20px',marginBottom:'20px'}}>                                        
                                        <span>SQL操作: </span><input />
                                        <button value='查询'>查询</button>
                                    </div>                                    
                                    <table style={{width:'100%'}}>
                                        <thead>
                                            <tr>
                                                <th>SQL操作</th>
                                                <th>追踪次数</th>
                                                <th>平均执行时间(ms)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                sjk_slowSql && sjk_slowSql.map((value,i)=>{
                                                    return(
                                                        <tr key={i} onClick={()=>shuju(value.dataBaseSqlViewVO.rpc)}>
                                                            <td>{value.dataBaseSqlViewVO.sqlInfo}</td>
                                                            <td>{value.invokeTime}</td>
                                                            <td>{value.avgTime}</td>
                                                        </tr>
                                                    )
                                                })
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div style={{clear:'both'}}></div>
                    </div>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        sjk_right:state.vars.sjk_right,
        headerOptionsID : state.vars.headerOptionsID,//默认ID
        sjkList : state.vars.sjkList,
        sjk_slowSql : state.vars.sjk_slowSql,
        sjk_slowSql1: state.vars.sjk_slowSql1,
        sjk_slowSql2: state.vars.sjk_slowSql2,
        sjk_top : state.vars.sjk_top,
        sjk_qutu : state.vars.sjk_qutu,
        shuju:state.vars.shuju,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:(headerOptionsID)=>{
            // console.log('qwe',headerOptionsID)
    		let obj1={//数据库一览
                type: 'get',
                url: 'apm/dbOverview.pinpoint' ,
                data: 'appId='+headerOptionsID,
                dataType: 'json'
            };
            ajax(obj1,callback1);
            // console.log('数据库一览',obj1)
            function callback1(data){
                console.log('数据库一览',data)
                dispatch(actions.setVars('sjkList',data.objectList))
                console.log('数据库一览',data.objectList)
                dispatch(actions.setVars('sjk_slowSql1',data.objectList[0].apiMetaId))
                console.log('数据库一览1',data.objectList[0].apiMetaId,'=apiMetaId')
                dispatch(actions.setVars('sjk_slowSql2',data.objectList[0].sqlMetaDataId))
                console.log('数据库一览2',data.objectList[0].sqlMetaDataId,'=sqlMetaDataId')
            }

            let obj2={//top5堆叠
                type: 'get',
                url: 'apm/appExpensiveSqlByTime.pinpoint' ,
                data: 'selectType='+'SQL_BY_APP',
                dataType: 'json'
            };
            ajax(obj2,callback2);
            // console.log('top5堆叠',obj2)
            function callback2(data){
                console.log('top5堆叠',data);
                let sjk_top={
                    maxTime:[],
                    minTime:[],
                    avgTime:[],
                    yaxisList:[],
                    totalTime:[],
                }
                
                sjk_top.xaxisList=data.obj.xaxisList;
                for(let i=0;i<data.obj.yaxisList.length;i++){
                    sjk_top.totalTime.push(data.obj.yaxisList[i].dataBaseSqlViewVO);
                    sjk_top.maxTime.push(Number(data.obj.yaxisList[i].maxTime));
                    sjk_top.minTime.push(Number(data.obj.yaxisList[i].minTime));
                    sjk_top.avgTime.push(Number(data.obj.yaxisList[i].avgTime));
                }
                console.log('sjk_top',sjk_top)
                dispatch(actions.setVars('sjk_top',sjk_top))
            }

            let obj3={//慢sql列表
                type: 'get',
                url: 'apm/traceExpensiveSql.pinpoint' ,
                data: 'appId='+headerOptionsID,
                dataType: 'json'
            };
            ajax(obj3,callback3);
            
            function callback3(data){
                console.log('慢sql列表',data)
                dispatch(actions.setVars('sjk_slowSql',data.objectList))
            }

            let obj4={//数据库响应时间曲线
                type: 'get',
                url: 'apm/databaseResponse.pinpoint' ,
                data: 'appId='+headerOptionsID+'&selectType='+'SQL_TRANSACTION_RESPONSE',//加下拉框
                dataType: 'json'
            };
            ajax(obj4,callback4);
            function callback4(data){
                console.log('数据库响应时间曲线',data)
                let sjk_qutu={
                    maxTime:[],
                    avgTime:[],
                    yaxisList:[],
                    invokeCount:[],
                }
                sjk_qutu.xaxisList=data.obj.xaxisList;
                for(let i=0;i<data.obj.yaxisList.length;i++){
                    sjk_qutu.invokeCount.push(data.obj.yaxisList[i].invokeCount);
                    sjk_qutu.maxTime.push(Number(data.obj.yaxisList[i].totalTime));
                    sjk_qutu.avgTime.push(Number(data.obj.yaxisList[i].avgTime));
                }
                // console.log('sjk_qutu',sjk_qutu)
                dispatch(actions.setVars('sjk_qutu',sjk_qutu))
                //dispatch(actions.setVars('sjkList',data.objectList))
            }
    	},
    	init:()=>{
    		let height=$('#sjk').css('height');
            $('#secondTree').css('height',height);
    	},
        showAdd:()=>{
            dispatch(actions.setVars('addInstrument',true))
        },
        showRight:(id)=>{
            dispatch(actions.setVars('sjk_right',true));
            dispatch(actions.setVars('sjk_sqlId',id));
        },
        shuju:(id)=>{
            dispatch(actions.setVars('sjkzz',true));
            dispatch(actions.setVars('rpc',id));
            // console.log(sjkzz,'sjkzz')
        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Sjk);