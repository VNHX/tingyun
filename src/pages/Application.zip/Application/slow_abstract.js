//慢事务追踪，摘要组件
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import './slow_abstract.css';
import SwChart4 from 'pages/chart/SwChart4.js';
import myAjax from 'pages/functionalCom/myAjax.js';
const ajax=myAjax.myAjax;

class Slow_abstract extends Component{  
	componentWillMount() {
        // this.props.willMount(this.props.headerOptionsID,this.props.transactionId);
        // // console.log('hx789',this.props.transactionId);
        // console.log('hx456',this.props.headerOptionsID);

    }
    componentDidMount() {
        this.props.init();
        this.props.willMount(this.props.headerOptionsID,this.props.spanId);
        console.log('hx789',this.props.spanId);
        // console.log('hx456',this.props.headerOptionsID);

    }
    render() {
        let {sw_abstractData,swChartData}=this.props;
        console.log('asd',swChartData)
        return (
            <div className='slow_abstract'>
             <SwChart4 swChartData={swChartData} />
            	<table>
            		<thead>
            			<tr>
            				<th>最慢组件</th><th>调用次数</th><th>持续时间（s）</th><th>占比（%）</th>
            			</tr>
            		</thead>
            		<tbody>
            			{
            				sw_abstractData && sw_abstractData.map((value,i)=>{
            					return(
            						<tr key={i}>
            							<td>{value.apiInfo}</td>
            							<td>{value.invokeCount}</td>
            							<td>{value.totalTime}</td>
            							<td>{value.timePer}</td>
            						</tr>
            					)
            				})
            			}
            		</tbody>
            	</table>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        headerOptionsID : state.vars.headerOptionsID,//默认ID
        spanId : state.vars.spanId,
        sw_abstractData : state.vars.sw_abstractData,
        swChartData : state.vars.swChartData,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:(headerOptionsID,spanId)=>{
            console.log('12',spanId)
    		let obj1={//慢组件
                type: 'get',
                url: 'apm/slowestComponentList.pinpoint' ,
                data: 'spanId='+spanId,
                dataType: 'json'
            };
            console.log('慢组件01',obj1)
            ajax(obj1,callback1);
            function callback1(data){
                console.log('慢组件',data)
                dispatch(actions.setVars('sw_abstractData',data.objectList))
            }

            let obj2={//百分比表格
                type: 'get',
                url: 'apm/tranInvokeTrace.pinpoint' ,
                data: 'spanId='+spanId,
                dataType: 'json'
            };
            ajax(obj2,callback2);
            console.log('凸凸凸',obj2)
            function callback2(data){
                console.log('凸凸凸',data)
                let swChartData={
                    apiInfo:[],
                    endElapsed:[],
                    methodId:[],
                    spanEventId:[]
                }
                console.log('放图',swChartData);
                for(let i=0;i<data.objectList.length;i++){
                    swChartData.apiInfo.push(data.objectList[i].apiInfo);
                    swChartData.endElapsed.push(data.objectList[i].endElapsed);
                    swChartData.methodId.push(data.objectList[i].methodId);
                    swChartData.spanEventId.push(Number(data.objectList[i].spanEventId));
                }
                dispatch(actions.setVars('swChartData',swChartData))
                console.log('放图',swChartData);
            }
    	},
    	init:()=>{
    		
    	}
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Slow_abstract);