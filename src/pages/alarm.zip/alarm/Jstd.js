//接收通道
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import NewJs from './newJs.js';
import { Icon } from 'antd';
import './jstd.css';

import myAjax from 'pages/functionalCom/myAjax.js';
const ajax = myAjax.myAjax

class Jstd extends Component{  
	componentWillMount() {
        this.props.willMount();
    }
    componentDidMount() {
        this.props.init();
    }
    
    render() {
        let {initData,newJs=false,showNewjs,show_edit,edit,editUser,alarm=false,show_comfire,delUserBox,nowId,initData1}=this.props;
        
        return (
            <div className='content'>
                <div className='jstd_title'>
                    <div className='jstd_title_left'>警报接收人<input type='text' /></div>
                    <div className='jstd_title_right' onClick={()=>showNewjs()}><Icon type="plus" />新建警报接收人</div>
                </div>
                <table className='jstd_table'>
                    <thead>
                        <tr>
                            <th>接收人姓名</th>
                            <th>邮箱地址</th>
                            <th>手机号码</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            initData&&initData.map((value,index)=>{
                                return (
                                    <tr key={index} data-id={value.id}>
                                        <td>{value.name}</td>
                                        <td>{value.email}</td>
                                        <td>{value.phoneNumber}</td>
                                        <td className='jstd_operation'><Icon title='编辑' type="form" onClick={()=>show_edit(true,0,value.id)} /><Icon title='删除' type="delete" onClick={()=>show_comfire(true,0)}/></td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                {newJs && <NewJs/>}
                <div style={{display:edit?'block':'none'}} className='jstd_edit_box'>
                        <div className='edit_info'>
                            <div className='edit_title'><Icon style={{fontSize:'15px',float:'right',marginRight:'0px',marginTop:'0.3px',cursor:'pointer'}} type="close-circle" onClick={()=>show_edit(false)} /></div>
                            <table id='alert_table'>
                                <tbody>
                                    <tr>
                                        <td>接收人姓名</td>
                                        <td><input id='userName'/></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;&nbsp;邮箱地址</td>
                                        <td><input id='userEmail'/></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;&nbsp;手机号码</td>
                                        <td><input id='userPhone' /></td>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;&nbsp;密码</td>
                                        <td><input id='password' /></td>
                                    </tr>
                                </tbody>
                            </table>
                            <div className='edit_button'>
                                <button onClick={()=>editUser(false,nowId)}>确定</button><button onClick={()=>show_edit(false)}>取消</button>
                            </div>
                        </div>
                    </div>
                {
                    alarm&&<div className='jstd_alarm_box'>
                        <div className='jstd_alarm_content'>
                            <button onClick={()=>delUserBox(false,nowId)}>确认</button><button onClick={()=>show_comfire(false)}>取消</button>
                        </div>
                    </div>
                }
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        newJs:state.vars.newJs,
        edit:state.vars.edit,
        alarm:state.vars.alarm,
        initData:state.vars.initData,
        initData1:state.vars.initData1,
        nowId:state.vars.nowId,
        // isShow:state.vars.isShow,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:()=>{
            dispatch(actions.setVars('newJs',false));
            let getUserInfo = {
                url:'apm/userList.pinpoint',
                data:'',
                type:'get',
                dataType:'json'
            }
            ajax(getUserInfo,callbackUser)
            function callbackUser(data){
                    console.log('查询所有用户',data)
                dispatch(actions.setVars('initData',data.objectList));

            //     let initData1={
            //         id:[],
            // }
            // for(let i=0;i<data.objectList.length;i++){
            //     initData1.id.push(data.objectList[i].id)
            // }
            //     console.log('查询所有用户',initData1)
            var initData1;//用于存放取出的数组的值
            for(var i=0;i<data.objectList.length;i++){
                initData1=data.objectList[i].id;//数组的索引是从0开始的
            console.log(initData1);//把取出的值打印在控制台上
            
            }
                dispatch(actions.setVars('initData1',initData1));
            }
    	},
    	init:()=>{
    	},
        showNewjs:()=>{
            dispatch(actions.setVars('newJs',true)); 
        },
        show_edit:(isShow,index,id)=>{
            console.log('确认0',id);
            var tdArrContent =[];
            dispatch(actions.setVars('edit',isShow));   
            if(isShow==true){
                let tdArr = $('.jstd_table tbody tr').eq(index).find('td');
                let trArr = $('#alert_table tbody tr').children('td:odd').children();
                for(let i = 0;i < tdArr.length-1; i++){
                    tdArrContent.push(tdArr[i].innerHTML);
                    trArr[i].value = tdArrContent[i]
                }
            }else{
                tdArrContent =[];
            }
            dispatch(actions.setVars('nowId',id))
            console.log('查询所有用户id',id)
        },
        show_comfire:(isShow)=>{
            dispatch(actions.setVars('alarm',isShow));
        },
        editUser:(isShow,nowId)=>{
            console.log(nowId,'修改0')
            let edit_user_data = {
                url:'apm/updateUserById.pinpoint',
                data:'name='+$('#userName').val()+'&pwd='+$('#password').val()+'&phoneNumber='+$('#userPhone').val()+'&email='+$('#userEmail').val()+'&id='+nowId,
                dataType:'json',
                type:'get',
            }
            console.log('修改用户信息1',edit_user_data)
            ajax(edit_user_data,callback)
            function callback (data){
                console.log('修改用户信息2',data.objectList)
            }
            dispatch(actions.setVars('edit',isShow));
            console.log('修改成功3', isShow)
        },
        delUserBox:(isShow,nowId)=>{
            let delUserInfo = {
                url:'apm/deleteUserById.pinpoint',
                dataType:'json',
                type:'get',
                data:'id='+nowId,
            }
            console.log('删除用户',delUserInfo)
            ajax(delUserInfo,callbackDel)

            function callbackDel (data){
                
                console.log('删除用户',data.objectList)
            }

            dispatch(actions.setVars('alarm',isShow)); 
             console.log('删除用户成功',isShow)  
        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Jstd);