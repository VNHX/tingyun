//策略设置
import React, {Component} from 'react';
import {connect} from 'react-redux';
import actions from 'actions';
import NewCl from './newCl.js';
import { Icon } from 'antd';
import './clsz.css';

import myAjax from 'pages/functionalCom/myAjax.js';
const ajax = myAjax.myAjax

class Clsz extends Component{  
	componentWillMount() {
        this.props.willMount();
    }
    componentDidMount() {
        this.props.init();
    }
    
    render() {
    	let {newJsCl=false,showNewcl,clInitData,clInitData1}=this.props;
        return (
            <div className='content'>
                <div className='clsz_title'>                    
                    <div className='clsz_title_left'>警报策略</div>
                    <div className='clsz_title_right' onClick={()=>showNewcl()}><Icon type="plus" />新建策略</div>
                </div>
                <table className='clsz_table'>
                    <thead>
                        <tr>
                            <th>策略</th>
                            <th>监控项</th>
                            <th>策略摘要</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            clInitData&&clInitData.map((value,index)=>{
                                return (
                                    <tr key={index}>
                                        <td>{value.name}</td>
                                        <td>{value.strategyType}</td>
                                        <td>
                                            {
                                                value.monitorList.map((value,index)=>{
                                                    return(
                                                        <div key={index} style={{cursor:'pointer'}} className='clsz_div'>已包含监控类型：{value.type}
                                                            <ul className='clsz_divChild'>
                                                                <li>RPM：{value.rpm}</li>
                                                                <li>监控类型：{value.type}</li>
                                                                <li>阀值：{value.threshold}</li>
                                                                <li>持续时间：{value.time}</li>
                                                            </ul>
                                                        </div>
                                                    )  
                                                })
                                            }
                                        </td>
                                        {/* <td>{value.id}</td> */}
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                {newJsCl && <NewCl/>}
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        
        newJsCl:state.vars.newJsCl,

        clInitData:state.vars.clInitData,
        clInitData1:state.vars.clInitData1
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
    	willMount:()=>{
            let initInfo = {
                type:'get',
                url:'apm/monitor/findMonitorStrategy.pinpoint',
                data:'',
                dataType:'json',
            };

            ajax(initInfo,callback3);

            function callback3(data){
                    console.log(data,'查询监控策略')
                dispatch(actions.setVars('clInitData',data.objectList))
                var clInitData1;//用于存放取出的数组的值
                for(var i=0;i<data.objectList.length;i++){
                    clInitData1=data.objectList[i].id;//数组的索引是从0开始的
                console.log(clInitData1);//把取出的值打印在控制台上
                }
                dispatch(actions.setVars('clInitData1',clInitData1));
            }
    	},
    	init:()=>{
    		
    	},
        showNewcl:()=>{

            dispatch(actions.setVars('newJsCl',true));
        }
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Clsz);